#!/usr/bin/python3
# -*- coding: utf8 -*-
# reponse.py

import cgi		# charger le module CGI de python
import locale # module pour gérer les locales (latin1, utf8 etc...)
import sys    # module pour gérer le système
locale.getpreferredencoding = lambda: 'UTF-8'
sys.stdin = open('/dev/stdin', 'r')
sys.stdout = open('/dev/stdout', 'w')
sys.stderr = open('/dev/stderr', 'w')

print("Content-Type: text/html ; charset=utf-8\n")	# préciser dans l’entête HTTP le format du document

form=cgi.FieldStorage()	# La classe Fieldstorage permet de récupérer les données transmises
prenom  = form.getvalue("prenom")
nom     = form.getvalue("nom")
email   = form.getvalue("email")
objet   = form.getvalue("objet")
message = form.getvalue("message")

horaire2 = form.getvalue("heure")
horaires2 = ",".join(horaire2)


msg = """{} {},<br/>
{}<br/>
objet de la demande : {}<br/>
{} <br/>
heure: {} <br/>
""".format(prenom, nom, email, objet, message, horaires2) # Formatter la réponse

print(msg)				    # Afficher le résultat
