<!DOCTYPE html>
<html>
	<head>
		<!-- En-tête de la page -->
		<meta charset="utf-8" />
		<title>Exemple de formulaires</title>
	</head>
	<body>
	<!-- Corps de la page -->
	<p>Voici la 2° page</p>

<?php
	echo "<h1>Bonjour ".$_GET["nom"]."</h1>";
	?>
</body>
</html>


