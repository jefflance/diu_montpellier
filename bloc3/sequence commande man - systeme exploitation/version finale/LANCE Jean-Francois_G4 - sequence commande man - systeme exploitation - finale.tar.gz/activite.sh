#!/usr/bin/env bash

echo "Création de l'arborescence" 

# log in to the home user dir
cd ${HOME}

# create the directory tree for the activity
mkdir -p activite/{donnees,calculs}/afrique/{ukraine,kenya,cameroun,ethiopie,congo,mali,cote_ivoire} activite/{donnees,calculs}/europe/{albanie,allemagne,italie,france,pologne,espagne}/ activite/{donnees,calculs}/asie/{nepal,laos,chine,vietnam}/
mkdir activite/medias

# create dummy files in dirs
# these files doesn't have any content but occupy space on disk
for continent_folder in activite/donnees/*; do
   mkdir "${continent_folder}/medias"
   mkdir "${continent_folder}/pub"
   for country in "${continent_folder}"/* ; do
      if [ "$(basename ${country})" != "medias" ]; then
         dd if=/dev/zero of="${continent_folder}/medias/$(basename ${country}).jpeg" bs=512 count=1
	 chmod 444 ${continent_folder}/medias/$(basename ${country}).jpeg
      fi
   done
   ln -s "${HOME}/${continent_folder}/medias" "${HOME}/activite/medias/$(basename ${continent_folder})"
   chmod 444 "${continent_folder}/medias"
   for i in $(seq 1 10); do
      touch ${continent_folder}/pub/img${i}.png
   done
   for i in $(echo {a..g}); do
      touch ${continent_folder}/pub/dat${i}
   done
done

chmod 755 "${HOME}/activite/donnees/asie/medias"


for country_folder in activite/donnees/*/*; do
   if [ $(basename ${country_folder}) != "medias" ] && [ $(basename ${country_folder}) != "pub" ]; then
      dd if=/dev/zero of="${country_folder}/LISEZMOI.md" bs=1024 count=2
      dd if=/dev/zero of="${country_folder}/population.txt" bs=1024 count=1
      dd if=/dev/zero of="${country_folder}/revenu.csv" bs=2048 count=1
      dd if=/dev/zero of="${country_folder}/alphabetisation.txt" bs=4096 count=1
      chmod 600 "${country_folder}/LISEZMOI.md"
   fi
done

for country_folder in activite/calculs/*/*; do
   touch "${country_folder}/population_par_region.txt"
   dd if=/dev/zero of="${country_folder}/revenu_median.xls" bs=2048 count=1
   dd if=/dev/zero of="${country_folder}/indice_alphabetisation.xls" bs=4096 count=1
done

echo "Ok."
