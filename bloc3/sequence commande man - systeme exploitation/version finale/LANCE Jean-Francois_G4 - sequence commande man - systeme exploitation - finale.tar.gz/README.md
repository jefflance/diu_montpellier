Notes de version
---

titre: Séquence Commande man - Système d'exploitation

version: finale

auteur: Jean-François LANCE

date: 08/07/19

---

Cette version est basée sur la version présentée à l'oral et évaluée par les pairs.

Suite aux retours, j'y ai apporté quelques modifications qui ne sont pas nécessairement présentes
dans les documents de mes collègues.

Fichiers utilisés pour cette version:

- document d'activité: ``LANCE_Jean-Francois_G4_sequence - systeme exploitation - commande man - finale.pdf``
- script utilisé dans l'activité: ``activite.sh``
- ce fichier: ``README.md``